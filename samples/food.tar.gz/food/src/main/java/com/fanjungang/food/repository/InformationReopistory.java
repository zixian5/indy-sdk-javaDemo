package com.fanjungang.food.repository;

import com.fanjungang.food.model.Information;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InformationReopistory extends JpaRepository<Information , Integer> {
}
