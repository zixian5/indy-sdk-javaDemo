package com.fanjungang.food.repository;

import com.fanjungang.food.model.External;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ExternalRepository extends JpaRepository<External, Integer> {
}
